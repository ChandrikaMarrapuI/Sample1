package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	
	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody Employee employee){
		return employeeService.saveEmployee(employee);
	}

		 
	
	
	@GetMapping("/gallemployee")
	public List<Employee> getAllEmployees(){
		return employeeService.getAllEmployees();
	}
	
	@PutMapping("/update/{id}")
    public Employee updateEmployee(@RequestBody Employee employee,@PathVariable("id") Long id)
    {
        return employeeService.updateEmployee(employee);
    }
	
	
	@DeleteMapping("/delete/{id}")
    public String deleteEmployeeById(@PathVariable("id") Long id)
    {
		employeeService.deleteEmployeeById(id);
        return "Deleted Successfully";
    }
	
}
